def linear_search_product_indices(product_list, target_product):
    return [index for index, product in enumerate(product_list) if product == target_product]

# Example usage:
products = ["shoes", "boot", "loafer", "shoes", "sandal", "shoes"]
target = "shoes"
result = linear_search_product_indices(products, target)
print(result)